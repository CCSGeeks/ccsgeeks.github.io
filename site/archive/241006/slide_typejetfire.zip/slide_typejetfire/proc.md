## task_struct

```c
struct task_struct {
    volatile enum state; //运行状态
    struct thread_info *thread_info;
    unsigned int flags; // 进程标记符
    struct list_head tasks;// 进程链表
    struct mm_struct *mm, *active_mm;//进程地址空间

    // 进程标识符
    pid_t pid;
    pid_t tgid;

    // 亲属关系
    struct task_struct *parent;
    struct list_head children;
    struct list_head sibling;
    struct task_struct *group_leader;
    struct list_head thread_group;

    // 文件
    struct fs_struct *fs;// 进程当前目录
    struct files_struct *files;// 进程当前打开的文件

    // CPU time and statistics
    cputime_t utime;//用户态运行时间
    cputime_t stime;//内核态运行时间
    struct timespec start_time;//进程开始执行时间
    struct task_cputime cputime_expires;//cpu累计执行时间

    // // I/O 
    // struct io_context *io_context;
    // struct task_io_accounting ioac;

    // 信号处理
 struct signal_struct {
        sigset_t sigs; // 信号的集合
        sigset_t sigpending; // 进程待处理信号的集合
        sigset_t sighold; // 进程当前持有的信号集合
        sigset_t sigignore; // 进程忽略的信号集合
        sigset_t sigcatch; // 进程捕获的信号集合
        struct sigpending *sigpending_queue; // 待处理信号的队列
        struct sigaction *action; // 信号动作数组
        int sigcnt; // 正在处理的信号计数器
    } sighand;

    // // 进程调度
    // int prio, static_prio, normal_prio;
    // unsigned int rt_priority;
    // const struct sched_class *sched_class;
    // struct sched_entity se;
    // struct sched_entity *sep;

    // 进程退出状态
    int exit_state;
    int exit_code, exit_signal;

    // 内核栈
    void *stack;

    // // 进程追踪
    // struct audit_context *audit_context;
    // u32 parent_exec_id;
    // u32 self_exec_id;
};

```

## 结构体解析

### 进程状态
```c
enum proc_state {
    TASK_RUNNING = 0,
    TASK_RUNABLE,
    TASK_BLOCK,
    TASK_ZOMBIE,
    TASK_KILLED,
};
```

### 内存管理结构体
```c
struct mm_struct {
    struct vm_area_struct *mmap; // 指向虚拟内存区域链表的指针
    atomic_t mm_users; // 引用计数
};
```

### 文件系统结构体
```c
struct fs_struct {
    struct path root, pwd; // 根目录和当前工作目录的路径
};
```

### 文件结构体
```c
struct files_struct {
    struct fdtable *fdt; // 文件描述符表
};
```

## 系统调用

### 进程
wait(): 等待子进程结束。
clone(): 创建一个与当前进程相似的子进程，可以设置不同的标志和栈。

### 信号处理
sigaction(): 设置信号处理函数。
kill(): 向进程或线程发送信号。
sigprocmask(): 阻塞或解除阻塞信号。

### 时间管理
times(): 获取进程的CPU时间。
clock_gettime(): 获取精确的当前时间。

### 用户权限管理
setuid(): 设置用户ID。
setgid(): 设置组ID。



