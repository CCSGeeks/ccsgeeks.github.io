## shedule

### stage 1
1. 基本硬件中断机制            周杰
2. task_struct（增加状态/信号处理） 周杰
3. 同步并发原语（汇编级别）  罗君
4. 底层文件系统 （ext2）   李梓勤， 许正阳
5. mmlayout 内存管理(unit_test, fl 数据结构)  罗君， 李梓勤
6. 数据结构 （哈希表， 红黑树， 基数树） 张逸涵， 李梓勤

## stage 2
1. SoC 时钟（HPET/RTC）      （stage 1.1 基本硬件中断机制）
2. 进程调度 （简单调度）       （stage 1.2 task_struct （增加状态））
3. 同步并发原语（自旋锁级别）   （stage 1.3 同步并发原语（汇编级别）） 
4. crash consistency 文件系统 （stage 1.4 底层文件系统 （ext2->3）） 

## stage 3
1. 基本信号机制                （stage 1.2 task_struct （信号处理））
2. 同步并发机制（锁/信号量）    （stage 1.1 基本硬件中断机制 / stage 2.3 同步并发原语（自旋锁级别））
3. VFS(inode/dentry/file)    (stage 2.4 crash consistency 文件系统)
4. 多核调度                   （stage2.2 进程调度 （简单调度））

## stage 4
1. 信号机制                   （stage 2.1 SoC 时钟（HPET/RTC）/ stage 3.1 基本信号机制 / stage 3.2 同步并发机制（锁/信号量））
2. FS(with cache and sync)   （stage 2.4 crash consistency 文件系统 / stage 3.3  VFS(inode/dentry/file) ）
3. 驱动代码 （AHCI/ATA）

## stage 5
1. SMP 内核线程               （stage 4.1 信号机制 / stage 3.4 多核调度）
2. FS UID/GID                  (stage 4.2 FS)

## stage 6
1. 权限控制机制                 （stage 6.2 FS UID/GID ）
2. 中断下半部(软中断 / tasklet)   (stage 6.1 SMP 内核线程)

## stage 7
1. Blcok I/O 机制              (stage 6.2 中断下半部)