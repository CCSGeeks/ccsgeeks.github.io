# 虚拟文件系统设计

The Design of imoutOS Filesystem Hie

## Linux-comp Filesystem Syscalls

### In-kernel Process

#### Process Information

##### Current Directory

```c
int chdir(const char *path);
int fchdir(int fd);
// task_struct fs_struct path cwd;
```

##### Root Directory

```c
int chroot(const char *path);
// ignore it
```

#### File Descriptor

```c
int close(int fd);
mode_t umask(mode_t mask);
```

##### Duplication of file descriptor

```c
int dup(int oldfd);
int dup2(int oldfd, int newfd);
int dup3(int oldfd, int newfd, int flags);
```

##### Open a file descriptor

```c
int open(const char *pathname, int flags, ...
              /* mode_t mode */ );

int creat(const char *pathname, mode_t mode);

int openat(int dirfd, const char *pathname, int flags, ...
          /* mode_t mode */ );

/* Documented separately, in openat2(2): */
int openat2(int dirfd, const char *pathname,
          const struct open_how *how, size_t size);
```

##### Between-2-fds

```c
ssize_t sendfile(int out_fd, int in_fd, off_t *_Nullable offset,
        size_t count);
ssize_t splice(int fd_in, off_t *_Nullable off_in,
      int fd_out, off_t *_Nullable off_out,
      size_t len, unsigned int flags);
int pipe(int pipefd[2]);
int pipe2(int pipefd[2], int flags);
```

##### Other operations

```c
int fcntl(int fd, int op, ... /* arg */ );
```

```c
int ioctl(int fd, unsigned long op, ...);
```

### Modify Single File State

#### Read from Single File

```c
ssize_t read(int fd, void buf[.count], size_t count);
ssize_t readv(int fd, const struct iovec *iov, int iovcnt);
ssize_t preadv(int fd, const struct iovec *iov, int iovcnt,
               off_t offset);
ssize_t preadv2(int fd, const struct iovec *iov, int iovcnt,
               off_t offset, int flags);
```

#### Write to Single File

```c
ssize_t write(int fd, const void buf[.count], size_t count);
ssize_t writev(int fd, const struct iovec *iov, int iovcnt);
ssize_t pwritev(int fd, const struct iovec *iov, int iovcnt,
               off_t offset);
ssize_t pwritev2(int fd, const struct iovec *iov, int iovcnt,
               off_t offset, int flags);
```

```c
int truncate(const char *path, off_t length);
int ftruncate(int fd, off_t length);
int fallocate(int fd, int mode, off_t offset, off_t len); // ignore
```

// blocks

#### Read Metadata from Single File

##### stats

```c
int stat(const char *restrict pathname,
        struct stat *restrict statbuf);
int fstat(int fd, struct stat *statbuf);
int lstat(const char *restrict pathname,
        struct stat *restrict statbuf);
int fstatat(int dirfd, const char *restrict pathname,
        struct stat *restrict statbuf, int flags);
int statx(int dirfd, const char *restrict pathname, int flags,
         unsigned int mask, struct statx *restrict statxbuf);
```

##### Extended Attributes

```c
ssize_t getxattr(const char *path, const char *name,
                void value[.size], size_t size);
ssize_t lgetxattr(const char *path, const char *name,
                void value[.size], size_t size);
ssize_t fgetxattr(int fd, const char *name,
                void value[.size], size_t size);
```

```c
ssize_t listxattr(const char *path, char *_Nullable list, size_t size);
ssize_t llistxattr(const char *path, char *_Nullable list, size_t size);
ssize_t flistxattr(int fd, char *_Nullable list, size_t size);
```

#### Modify Metadata from Single File

##### Extended Attributes

```c
int setxattr(const char *path, const char *name,
             const void value[.size], size_t size, int flags);
int lsetxattr(const char *path, const char *name,
             const void value[.size], size_t size, int flags);
int fsetxattr(int fd, const char *name,
             const void value[.size], size_t size, int flags);
```

```c
int removexattr(const char *path, const char *name);
int lremovexattr(const char *path, const char *name);
int fremovexattr(int fd, const char *name);
```

##### Permissions

```c
int chmod(const char *pathname, mode_t mode);
int fchmod(int fd, mode_t mode);
int fchmodat(int dirfd, const char *pathname, mode_t mode, int flags);
```

```c
int chown(const char *pathname, uid_t owner, gid_t group);
int fchown(int fd, uid_t owner, gid_t group);
int lchown(const char *pathname, uid_t owner, gid_t group);
int fchownat(int dirfd, const char *pathname,
            uid_t owner, gid_t group, int flags);
```

```c
int access(const char *pathname, int mode);
int faccessat(int dirfd, const char *pathname, int mode, int flags);
int syscall(SYS_faccessat2,
           int dirfd, const char *pathname, int mode, int flags);
```

##### Timestamp of File

```c
int utime(const char *filename,
         const struct utimbuf *_Nullable times);
int utimes(const char *filename,
         const struct timeval times[_Nullable 2]);
int utimensat(int dirfd, const char *pathname,
             const struct timespec times[_Nullable 2], int flags);
int futimens(int fd, const struct timespec times[_Nullable 2]);
```

#### Name and Links

```c
int rename(const char *oldpath, const char *newpath);
int renameat(int olddirfd, const char *oldpath,
            int newdirfd, const char *newpath);
int renameat2(int olddirfd, const char *oldpath,
            int newdirfd, const char *newpath, unsigned int flags);
```

```c
int unlink(const char *pathname);
int unlinkat(int dirfd, const char *pathname, int flags);
```

```c
int link(const char *oldpath, const char *newpath);
int linkat(int olddirfd, const char *oldpath,
          int newdirfd, const char *newpath, int flags);
```

```c
int symlink(const char *target, const char *linkpath);
int symlinkat(const char *target, int newdirfd, const char *linkpath);
ssize_t readlink(const char *restrict pathname, char *restrict buf,
        size_t bufsiz);
ssize_t readlinkat(int dirfd, const char *restrict pathname,
        char *restrict buf, size_t bufsiz);
```

### Directoty Operations

```c
int mkdir(const char *pathname, mode_t mode);
int mkdirat(int dirfd, const char *pathname, mode_t mode);
int rmdir(const char *pathname);
long syscall(SYS_getdents, unsigned int fd, struct linux_dirent *dirp,
            unsigned int count);
ssize_t getdents64(int fd, void dirp[.count], size_t count);
int syscall(SYS_readdir, unsigned int fd,
           struct old_linux_dirent *dirp, unsigned int count);
```

### Filesystem State

#### Read Metadata of Filesystem

```c
int statfs(const char *path, struct statfs *buf);
int fstatfs(int fd, struct statfs *buf);
```

#### Mounts and Namespace

```c
int mount(const char *source, const char *target,
         const char *filesystemtype, unsigned long mountflags,
         const void *_Nullable data);
int umount(const char *target);
int umount2(const char *target, int flags);
int syscall(SYS_pivot_root, const char *new_root, const char *put_old);
```

### Sync

```c
void sync(void);
int fsync(int fildes);
int fdatasync(int fd);
int syncfs(int fd);
int msync(void addr[.length], size_t length, int flags);
```

## superblock



## FS 后端

### ext4

[lwext4 | ext2/ext3/ext4 filesystem library for microcontrollers](https://gkostka.github.io/lwext4/)

## References

[Overview of the Linux Virtual File System — The Linux Kernel documentation](https://docs.kernel.org/filesystems/vfs.html)

[Linux VFS机制简析（一） - 舰队 - 博客园](https://www.cnblogs.com/jimbo17/p/10107318.html)

[深入理解Linux内核——VFS | linkthinking](https://wushifublog.com/2020/05/22/%E6%B7%B1%E5%85%A5%E7%90%86%E8%A7%A3Linux%E5%86%85%E6%A0%B8%E2%80%94%E2%80%94VFS/)

Linux/LoongArch 系统调用 ABI
