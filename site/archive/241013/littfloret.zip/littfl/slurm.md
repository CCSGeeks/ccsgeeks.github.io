https://www.arch.jhu.edu/short-tutorial-how-to-create-a-slurm-script/ | 简短教程：如何创建 Slurm 脚本 – ARCH Advanced Research Computing --- Short Tutorial: How to Create a Slurm Script – ARCH Advanced Research Computing
https://docs.rc.fas.harvard.edu/kb/convenient-slurm-commands/ | 方便的 Slurm 命令 – FASRC DOCS --- Convenient Slurm Commands – FASRC DOCS
https://docs.rc.fas.harvard.edu/kb/running-jobs/ | 运行作业 – FASRC DOCS --- Running Jobs – FASRC DOCS
