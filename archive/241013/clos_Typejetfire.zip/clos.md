# Clos 
1953年， 贝尔实验室有一位名叫 Charles Clos 的研究员， 发表了一篇名为《A Study of Non-blocking Switching Networks》的文章， 介绍了一种 “用多级设备来实现无阻塞电话交换” 的方法。
![alt text](image-1.png)

## 纵横交换机
![alt text =30x30](image.png)
这种交换架构， 是一种开关矩阵， 每个交点（Crosspoint）都是一个开关。 交换机通过控制开关， 来完成从输入到输出的转发。 开关矩阵很像一块布的纤维,  所以，交换机的内部架构，被称为 Switch Fabric。Fabric，就是“纤维、布料”的意思。 随着电话用户数量急剧增加， 网络规模快速扩大， 基于crossbar模型的交换机在能力和成本上都无法满足要求。

## Fat tree
到了80年代， 随着计算机网络的兴起， 开始出现了各种网络拓扑结构， 例如星型、链型、环型、树型， 其中树型网络逐渐成为主流， 但这时的树形网络是收敛的。
2000年之后， 面对日益庞大的计算规模， 传统树型网络肯定是不行的了， 一种改进型树型网络开始出现， 它就是胖树（Fat-Tree）架构。
![alt text](image-2.png)

### Fat tree 结构
Fat-Tree结构共分为三层：核心层、汇聚层、接入层。一个k元的Fat-Tree可以归纳为5个特征：

1. 每台交换机都有k个端口；

2. 核心层为顶层，一共有(k/2)^2个交换机；

3. 一共有k个pod，每个pod有k台交换机组成。其中汇聚层和接入层各占k/2台交换机；

4. 接入层每个交换机可以容纳k/2台服务器，因此，k元Fat-Tree一共有k个pod，每个pod容纳 k^2^ /4个服务器，所有pod共能容纳 k^3^ /4台服务器；

![alt text](image-4.png) 


## Spine-Leaf
![alt text](image-8.png)
### Spine-leaf 结构
1. 每个叶交换机都与每个脊柱交换机相连， 形成一个全 mesh 拓扑结构。
<br>
2. 第三层脊柱-叶结构要求每个链接都被路由， 通常使用开放最短路径优先（Open Shortest Path First, OSPF）或边界网关协议（Border       Gateway Protocol, BGP）动态路由。
<br>
3. 叶节点之间只需单跳即可，最小化了延迟和瓶颈。



