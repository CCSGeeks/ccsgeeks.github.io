# Overall Process on miniob

## Key Struct/Class in Parsing SQL

### SessionEvent

```cpp
class SessionEvent
{
public:
  SessionEvent(Communicator *client);
  virtual ~SessionEvent();

  Communicator *get_communicator() const;
  Session      *session() const;

  void set_query(const string &query) { query_ = query; }

  const string &query() const { return query_; }
  SqlResult    *sql_result() { return &sql_result_; }
  SqlDebug     &sql_debug() { return sql_debug_; }

private:
  Communicator *communicator_ = nullptr;  ///< 与客户端通讯的对象
  SqlResult     sql_result_;              ///< SQL执行结果
  SqlDebug      sql_debug_;               ///< SQL调试信息
  string        query_;                   ///< SQL语句
};
```

`SessionEvent` 是描述一个 Session 的类。它负责抽象出

1. 一次 Session 的 SQL 输入和结果（和调试数据）。
    - `query_` 表示 SQL 输入的语句。
    - `sql_result_` 表示 SQL 的执行。
    - `sql_debug_` 表示 SQL 执行产生的调试信息。
2. 通讯的手段。
    - `communicator` 抽象了通讯的手段。


### SQLStageEvent

`SQLStageEvent` 结构体贯穿了 `MiniOB` 程序的始终。

```cpp
class SQLStageEvent
{
public:
  SQLStageEvent(SessionEvent *event, const string &sql);
  virtual ~SQLStageEvent() noexcept;

  SessionEvent *session_event() const { return session_event_; }

  const string                       &sql() const { return sql_; }
  const unique_ptr<ParsedSqlNode>    &sql_node() const { return sql_node_; }
  Stmt                               *stmt() const { return stmt_; }
  unique_ptr<PhysicalOperator>       &physical_operator() { return operator_; }
  const unique_ptr<PhysicalOperator> &physical_operator() const { return operator_; }

  void set_sql(const char *sql) { sql_ = sql; }
  void set_sql_node(unique_ptr<ParsedSqlNode> sql_node) { sql_node_ = std::move(sql_node); }
  void set_stmt(Stmt *stmt) { stmt_ = stmt; }
  void set_operator(unique_ptr<PhysicalOperator> oper) { operator_ = std::move(oper); }

private:
  SessionEvent                *session_event_ = nullptr;
  string                       sql_;             ///< 处理的SQL语句
  unique_ptr<ParsedSqlNode>    sql_node_;        ///< 语法解析后的SQL命令
  Stmt                        *stmt_ = nullptr;  ///< Resolver之后生成的数据结构
  unique_ptr<PhysicalOperator> operator_;        ///< 生成的执行计划，也可能没有
};
```

分别对应了 4 个阶段：

1. Parse 阶段，主流程见 [ Parser 笔记 ](./parse.md)。将 string 的 `sql_` 处理
   成 `ParsedSqlNode` 的 `sql_node_` 。
2. Resolver 阶段，主流程见 [Resolver 笔记](./resolver.md) 。将 `ParsedSqlNode`
   的 `sql_node_` 处理成 `Stmt` 的 `stmt_` 。
3. Transformer 和 Optimzer 阶段。
4. Executor 阶段。主流程见 [Executor 笔记](./exec.md) 。将 `PhysicalOperator`
   和 `CommandExecutor` 变成 `SqlResult` 。

## 各阶段入口

总的入口在 `src/observer/net/sql_task_handler.cpp:58` 中。

`SqlTaskHandler::handle_sql` 依次调用了：

0. QueryCacheStage::handle_request
1. ParseStage::handle_request
2. ResolveStage::handle_request
3. OptimizeStage::handle_request
4. ExecuteStage::handle_request
<!-- ```c -->
<!-- // src/observer/net/sql_task_handler.cpp -->
<!-- ``` -->
<!--  -->
<!-- ## ParseStage::handle_request -->
<!--  -->
<!-- ## ResolveStage::handle_request -->
<!--  -->
<!-- ## OptimizeStage::handle_request -->
<!--  -->
<!-- ## ExecStage::handle_request -->
