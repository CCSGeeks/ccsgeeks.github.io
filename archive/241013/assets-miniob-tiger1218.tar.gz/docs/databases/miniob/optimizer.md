# MiniOB Executor

从 `OptimizeStage::handle_request` 开始。

（`src/observer/sql/optimizer/optimize_stage.cpp:32`）

大概可以分为以下四个阶段：

1. LogicalOperator 生成。主要由 `LogicalPlanGenerator` 类管理。
2. 重写 LogicalOperation 。主要由 `Rewriter` 类管理。
3. 优化 LogicalOperation 。这一步暂时没有内容。见
   `src/observer/sql/optimizer/optimize_stage.cpp:70`
4. PhysicalPlanGenerator 生成。主要由 `PhysicalPlanGenerator` 类管理。

具体的说明见 `src/observer/sql/optimizer/optimize_stage.h` 。

## LogicalOperator 生成

具体逻辑：`LogicalPlanGenerator::create` from
`src/observer/sql/optimizer/logical_plan_generator.cpp`

### 支持范围

- CALC
- SELECT
- INSERT
- DELETE
- EXPLAIN

### Operation 列表

See `src/observer/sql/operator/*`.

### Example: SelectStmt

## Rewrite 重写 LogicalOperation
```cpp
rewrite(logical_operator);
```

### rewrite

`src/observer/sql/optimizer/rewriter.cpp:29`

## Optimize 优化 LogicalOperation

```cpp
optimize(logical_operator);
```

## PhysicalPlanGenerator 生成

```cpp
generate_physical_plan(logical_operator, physical_operator, sql_event->session_event()->session());
```
