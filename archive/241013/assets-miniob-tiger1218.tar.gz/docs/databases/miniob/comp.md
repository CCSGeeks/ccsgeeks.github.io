# Competition Related Information for MiniOB

## Overview

[2024OB大赛-技术方案\_终\_.pdf · main · CSC / CSC-OB / OB-2024 · GitLab](https://gitlab.eduxiji.net/csc1/csc-ob/ob-2024/-/blob/main/2024OB%E5%A4%A7%E8%B5%9B-%E6%8A%80%E6%9C%AF%E6%96%B9%E6%A1%88_%E7%BB%88_.pdf)

前十 == 满分

初赛成绩不计入决赛成绩和总成绩。

<!-- 初赛得分占比 and 决赛得分占比是未知的。 -->

初赛有向量数据库。

## MiniOB 2022

[OceanBase 社区](https://open.oceanbase.com/train?questionId=500003)

## MiniOB 2023

[OceanBase 社区](https://open.oceanbase.com/train?questionId=600004)

### Easy 简单题

#### 1. Basic

不破坏原有题目。

## Vector Database System

Survey of vector database management systems VLDBJ'2024

[2310.14021v1.pdf](https://arxiv.org/pdf/2310.14021)

A Comprehensive Survey on Vector Database: Storage and Retrieval Technique, Challenge

[2310.11703v1.pdf](https://arxiv.org/pdf/2310.11703)

### Competition

向量的存储及查询、向量相似度计算、近似近邻搜索

## MiniOB 2024

支持删表、扩展支持日期字段、变长数据存储、多字段索引支持、表达式、向量
检索
