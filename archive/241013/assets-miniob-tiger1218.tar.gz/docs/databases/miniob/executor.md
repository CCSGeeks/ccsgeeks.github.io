# MiniOB Executor

## Overview

```cpp
RC ExecuteStage::handle_request(SQLStageEvent *sql_event)
{
  RC rc = RC::SUCCESS;

  const unique_ptr<PhysicalOperator> &physical_operator = sql_event->physical_operator();
  if (physical_operator != nullptr) {
    return handle_request_with_physical_operator(sql_event);
  }

  SessionEvent *session_event = sql_event->session_event();

  Stmt *stmt = sql_event->stmt();
  if (stmt != nullptr) {
    CommandExecutor command_executor;
    rc = command_executor.execute(sql_event);
    session_event->sql_result()->set_return_code(rc);
  } else {
    return RC::INTERNAL;
  }
  return rc;
}
```

## 存在 PhysicalOperator 时

## 无 PhysicalOperator 时

`src/observer/sql/executor/command_executor.cpp` 中的 `CommandExecutor::
execute` 。

1. Create Index
2. Create Table
3. Desc Table
4. Help


## References

[15-445/645 Database Systems (Fall 2023) - Lecture Notes - 12 Query Processing I - 12-queryexecution1.pdf](https://15445.courses.cs.cmu.edu/fall2023/notes/12-queryexecution1.pdf)

[15-445/645 Database Systems (Fall 2023) - Lecture Notes - 13 Query Execution II - 13-queryexecution2.pdf](https://15445.courses.cs.cmu.edu/fall2023/notes/13-queryexecution2.pdf)

[第4章 查询处理 - MiniOB](https://oceanbase.github.io/miniob/lectures/lecture-4/)

[第5章 查询优化 - MiniOB](https://oceanbase.github.io/miniob/lectures/lecture-5/)

[MiniOB 向量化执行 aggregation 和 group by 实现 - MiniOB](https://oceanbase.github.io/miniob/design/miniob-aggregation-and-group-by/#_6)
