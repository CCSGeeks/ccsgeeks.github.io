# MiniOB Resolver Stage

如 index.md 所述，我们从 `ResolveStage::handle_request` 开始说起。

`ResolveStage::handle_request` 的代码如下：

```cpp
RC ResolveStage::handle_request(SQLStageEvent *sql_event)
{
  RC            rc            = RC::SUCCESS;
  SessionEvent *session_event = sql_event->session_event();
  SqlResult    *sql_result    = session_event->sql_result();

  Db *db = session_event->session()->get_current_db();
  if (nullptr == db) {
    LOG_ERROR("cannot find current db");
    rc = RC::SCHEMA_DB_NOT_EXIST;
    sql_result->set_return_code(rc);
    sql_result->set_state_string("no db selected");
    return rc;
  }

  ParsedSqlNode *sql_node = sql_event->sql_node().get();
  Stmt          *stmt     = nullptr;

  rc = Stmt::create_stmt(db, *sql_node, stmt);
  if (rc != RC::SUCCESS && rc != RC::UNIMPLEMENTED) {
    LOG_WARN("failed to create stmt. rc=%d:%s", rc, strrc(rc));
    sql_result->set_return_code(rc);
    return rc;
  }

  sql_event->set_stmt(stmt);

  return rc;
}
```

可以看出，实际执行 Resolve 任务是 Stmt::create_stmt 。这个函数定义在
`src/observer/sql/stmt/stmt.cpp:47` 。它会根据 SCF 来判断该语句类型，然后调用
对应的 `xxxxStmt::create` 。我们以 `InsertStmt::create` 为例，看看这个阶段都处
理了什么事务。

## InsertStmt::create

其实就是把 string / const char * 转换成对象。

比如：

在 InsertStmt 中就需要把 `inserts.relation_name` 变成 
`Table *table = db->find_table(table_name);` 。同时，它也会检查
`inserts.values.size()` 是否和 `field_num` 相等。
