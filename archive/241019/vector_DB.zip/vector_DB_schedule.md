# schedule

## stage 1

### vector_basic
1. 创建包含向量类型的表

        CREATE TABLE items (id int, embedding vector(3));

2. 插入向量类型的记录

        INSERT INTO items VALUES (1, '[1,2,3]');

3. 向量类型的算术运算（加法（+），减法（-），乘法（*），比较运算）

        select embedding + '[1.5,2.3,3.3]',
        embedding - '[1,2,3]',
        '[1,2,3]' - embedding 
        from items 
        where embedding > '[0,0,0]';


4. 实现距离表达式计算：
    l2_distance，cosine_distance，inner_product

### vector_format
使用列表（如：[1,2,3]）来表示向量

### vector_high_dim
最大 16000 维向量的存储和检索

## stage 2

### vector_rewrite
1. 创建 Ivf-Flat 向量索引

        CREATE VECTOR INDEX vector_idx 
        ON items (embedding) 
        WITH (distance=l2_distance, type=ivfflat, lists=245, probes=5);

2. 当查询为邻近向量检索且命中向量索引时，需要将 order by + limit 的查询计划改写为通过向量索引进行检索的查询计划。

### vector_search
1. 没有索引的场景下，支持向量检索功能（即精确检索）。
2. 完整的向量检索功能（包括向量索引构建，向量索引查询）

        SELECT * FROM TAB_VEC ORDER BY L2_DISTANCE(B, '[1,2,3]') LIMIT 1;
## stage 3

### ann_benchmark
1. 对 MiniOB 代码进行修改，以支持运行 ann-benchmarks 测试
2. 满足题目要求的性能