# ANN

## IVFFLAT

### 索引构建

#### kmeans
k均值算法试图将给定的数据分割为k个不相交的组（group）或者簇（cluster）， 每个簇的指标就是该组所有成员的均值。这个点通常称为质心， 指具有相同名称的算术实体， 并且可以被表示为任意维度中的向量。
![alt text](image.png)

![alt text](image-1.png)

![alt text](image-2.png)

![alt text](image-3.png)

#### 倒排文件索引

将向量的索引存储在对应簇的列表中。然后，通过这个索引来快速锁定需要比较的向量集合。

### 向量检索

用户指定一张新图像进行搜索。首先，将这张图片通过同样的特征提取模型转换成一个高维向量。然后，通过计算这个向量与所有质心的距离，找到离它最近的几个质心。在这几个质心对应的簇中，进一步进行精确的向量搜索，找到最相似的图像。

#### Delaunay triangulation

    图中的每个节点都有邻居节点
    距离相近的节点都互为邻居节点
    图中的所有连接线段数量最少（邻居对最少）

![alt text](image-4.png)

#### Voronoi Diagram

每一个Region围住的点都是离各自Nucleus最近的点。 在图上随便找一个位置，你将会发现这个位置到所属Nucleus的直线距离不会大于到达其余任意一个Nucleus的直线距离
![alt text](image-5.png)

## HNSW（Hierarchcal Navigable Small World graphs）

### 索引构建

在二维平面（二维向量空间）中的这些黑色节点，怎么从这些黑色的点中寻找离红点最近的点？
![alt text](image-6.png)
<br>
一种简单做法是把黑色中的某些点和点连起来，构建一个查找图，存下来。与点直接相连的点叫做这个点的邻居节点。<br>
查找的时候随机从某个黑色的点（起始遍历节点：entry point）出发，计算这个点和目标点的距离，然后再计算这个点的邻居节点和目标点的距离，选择距离目标节点距离最近的节点继续迭代。<br>
如果当前处理的黑色节点比所有邻居节点距离目标节点都近，则当前黑色节点就是距离最近的节点。
![alt text](image-7.png)
这种思路虽然行得通，但是存在一些问题：

1. 找到的结果不是最优的结果。
2. 如果是要返回最近的两个节点，而L和E之间没有连线，这将增加迭代次数，并且大大影响效率
3. 如何确定哪些节点应该互为邻居呢？
4. K点是个孤岛，如果随机初始的节点不是K点则它永远无法访问到，而K作为初始节点，则无法遍历其他节点，只能返回K，误差较大。

#### Delaunay triangulation

1. 所形成的三角形互不重叠
2. 所形成的三角形可以覆盖整个平面空间
3. 每个点均不在不包含该点的三角形外接圆内
4. 最小角最大化

![alt text](image-4.png)

    图中的每个节点都有邻居节点
    距离相近的节点都互为邻居节点
    图中的所有连接线段数量最少（邻居对最少）

![alt text](image-8.png)

但是德劳内三角剖分法有两个缺点：

1. 图的构建时间复杂度太高
2. 查找效率比较低：如果起始点和目标点之间的距离比较远，需要大量的迭代才能找到目标。

#### NEW（Navigable Small World graphs）

![alt text](image-9.png)
![alt text](image-10.png)
<!-- ![alt text](image-11.png) -->
![alt text](image-12.png)
![alt text](image-13.png)
![alt text](image-4.png)

#### HNEW（Hierarchcal Navigable Small World graphs）

![alt text](image-14.png)
![alt text](image-15.png)

## DISKANN
![alt text](image-16.png)
