# Systems Performance

##  介绍

### 1.1 软件栈
![alt text](image.png)

### 1.4 视角
![alt text](image-1.png)

| 性能分析视角 |  |
|:-----------|:-----|
| 工作负载分析 | 应用程序开发人员 |
| 资源分析 | 系统管理员 |

### 1.5 性能分析的挑战性
|||
|:--|:--|
| 主观性 | 技术一般是客观的，但性能常常是主观的 <br> “The average disk I/O response time is 1 ms”是“好”还是“差”|
|复杂性|系统整体的复杂性，缺乏明确的分析起点 <br> 系统之间交互的复杂性 <br> 性能瓶颈的复杂性 <br> 生产环境负载的复杂性|
|多个原因|每个事件都是正常事件，但结合起来就导致了一个性能问题|
|多个性能问题|真正的任务不是寻找问题，而是辨别哪些是重要的问题<br> 量化分析问题的重要程度，<br>latency（延时）非常适合用来量化性能指标|

### 1.6 延时 latency
延时是用于等待的时间
![alt text](image-2.png)<br>
访问数据库的latency是100ms，其中阻塞再磁盘读写上占了80ms，那么可以消除磁盘读写的性能损耗，使得latency降至20ms，性能提升5倍（5x），这个提升是可以量化的；

上面计算方法不一定适用于其他metrics（指标）。

### 1.7 可观测性
|观察工具使用的方法	||
|--|--|
|计数器（counters）|操作计数，字节计数，延迟测量等<br>通常是整型变量且累计递增的|
|剖析（profiling）|在系统性能中，术语“剖析”通常是指使用执行采样的工具：通过测量数据的子集描绘目标的粗略情况|
|跟踪（tracing）|跟踪一般都是基于事件驱动的数据采集过程，例如针对系统调用的追踪工具strace，针对网络分析的抓包工具tcpdump，通用能追踪软硬件事件的跟踪工具如ftrace、bcc以及bpftrace等|

### 1.8 实验
|||
|-|-|
|macro-benchmark tools|模拟真实世界的工作负载|
|micro-benchmark tools|测试特定的组件，如网络，磁盘，CPU|

## 方法 Methodologies

### 2.1 术语 terminology
|术语||
|-|-|
|IOPS|每秒发生的输入和输出的次数|
|throughput|评价操作执行的速率；数据传输方面，throughput用于描述数据传输速度（bytes/s或bits/s）。某些场景下如数据库，吞吐量指的是操作的速度（每秒的操作数或者每秒业务数）|
|response time|一个操作完成所需要的时间，包括等待时间、执行时间、结果返回时间等|
|latency|延时时间，一个操作等待被执行所花费的时间；某些场景下，也可指response time|
|utilization（使用率）|资源的繁忙程度，存储容量的消耗率|
|saturation（饱和度）|资源无法提供服务的工作的排队程度|
|bottleneck（瓶颈）|限制系统性能的那个资源|
|workload|系统的输入或者对系统施加的负载|
|cache|用于复制或者缓冲一定量数据的高速存储区域|

### 2.2 模型
SUT: system under test 受测系统
![alt text](image-3.png)
queueing system 排队系统
![alt text](image-4.png)

### 2.3 概念

#### 2.3.3 权衡三角
性能/及时/成本低 择其二

#### 2.3.5 合适的层级
不同的公司和环境对性能有着不同的需求。

#### 2.3.6 何时停止分析
1. 当你已经解释了大部分性能问题的时候
2. 当潜在的投资回报率低于分析成本的时候
3. 当其他地方有更大的投资回报率的时候

#### 2.3.9 扩展性
![alt text](image-5.png)

#### 2.3.14 缓存
命中率 = 命中次数 / （命中次数 + 失效次数）
![alt text](image-6.png)

运行时间 = （命中率 * 命中延时）+（失效率 * 失效延时）

### 2.4 视角
#### 资源分析
适合资源分析的指标
- IOPS
- 吞吐量
- 使用率
- 饱和度

#### 工作负载分析
适合工作负载分析的指标
- 延时
- 吞吐量

### 2.5 性能分析方法
类型：观测分析，实验分析。

2.5.3  讹方法
2.5.4  ad hoc 核对清单法

### 2.6 建模
除观测（测量）和实验性测试（仿真）外，分析建模是第三类性能评估方法
![alt text](image-10.png)
#### 2.6.3 amdahl 定律
![alt text](image-11.png)
#### 2.6.4 通用扩展理论
![alt text](image-12.png)

### 2.8 2.9 2.10 统计 监测 可视化

## 操作系统
### 3.2 背景
#### 3.2.1 内核
![alt text](image-7.png)
![alt text](image-8.png)

#### 3.2.2 内核态和用户态

用户态切换到内核态，就叫 mode switch。
用户态切换到内核态的过程中，那些阻塞在比如磁盘等待、网络/ IO 等地方的进程还会引起 context switch，以便调度其他进程来执行；<br>
mode switch 和 context switch 会带来额外的 CPU 循环消耗。
|避免模式切换带来损耗的方法||
|-|-|
|user-mode syscalls|可以在用户态实现部分系统调用功能，linux kernel 通过将a virtual dynamic shared object(vDSO) 映射到进程地址空间中来实现，比如系统调用 gettimeofday, getcpu 等；| 
|memory mappings|used for demand paging；|
|kernel bypass	|比如 DPDK（the data plane development kit）；|
|kernel-mode applications|比如 TUX web 服务器，eBPF 技术等；|

#### 3.2.3 系统调用
系统调用请求内核执行特权的系统例程
#### 3.2.4 中断
同步中断，异步中断，中断线程，中断屏蔽。
#### 3.2.5 时钟和空闲
- tick latency 节拍延迟，假设时钟频率是 100 Hz ，那么进程延迟最多 10 ms 就会进入下一个 tick ；这个问题用高频率 real-time 中断方式解决。
- tick overhead，节拍损耗，ticks 消耗CPU 周期，并会干扰应用程序，造成操作系统抖动 
idle thread：当 CPU 空闲时，调度器会安排其到 idle 线程，idle 任务能够power down CPU 以节省能源；
#### 3.2.6 进程
用以执行用户级别程序的环境，包括内存地址空间，文件描述符，线程栈和寄存器。
#### 3.2.7 栈
用于存储临时数据的内存区域，用来存储比适合 cpu 寄存器集的数据更不重要的数据。

### 3.4 linux
#### 3.4.2 systemd
linux的服务管理器，具有功能
- 感知服务启动
- 服务时间统计。
#### 3.4.3 KPTI
KPTI(Kernel PageTable Isolation)全称内核页表隔离。 
之前，进程地址空间被分成了内核地址空间和用户地址空间。其中内核地址空间映射到了整个物理地址空间，而用户地址空间只能映射到指定的物理地址空间。内核地址空间和用户地址空间共用一个页全局目录表(PGD表示进程的整个地址空间) 。meltdown 漏洞就恰恰利用了这一点。攻击者在非法访问内核地址和 CPU 处理异常的时间窗口，通过访存微指令获取内核数据

#### 3.4.5 eBPD
![alt text](image-9.png)
BPF 字节码首先必须通过一个验证器，这个验证器会检查安全性，确保 BPF 程序不会崩溃或破坏内核。它还可能使用 BPF 类型格式（BTF）系统来理解数据类型和结构。BPF 程序可以通过 perf 环形缓冲区输出数据，这是一种高效的按事件输出数据的方式，或者通过 maps ，这种方式适合于统计数据





