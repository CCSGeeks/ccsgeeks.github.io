void bar();
void baz();
void foo();


void foo() {
    try { bar(); }
    catch (...) {
        /* ... */
    }
}

void bar() {
    baz();
}

void baz() {
    throw 42;
}
