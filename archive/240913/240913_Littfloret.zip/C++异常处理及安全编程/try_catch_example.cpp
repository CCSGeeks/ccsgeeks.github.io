#include <iostream>

void foo() {
    throw std::runtime_error("This");
}

void bar() {
    try {
        foo();
        std::cout << "what about me?" << std::endl;
    }
    catch (...) {
        std::cout << "is what we're talking about!"
            << std::endl;
    }
}
